# ВНЕ: тестовая структура и ID-связи применены

Проверено: 2026-10-06 17:07 UTC. Проект: xrocuwlofxhxoxajukne (VNEINFRASTRUCTURE_MAIN_COMM).

## Выполнено

В отдельной тестовой базе применены два независимо проверенных SQL-пакета:

- 20261006170437 — vne_restricted_test_baseline. SHA-256: a6f2a6b0266634fad7563f78ef396a5f2522a35429b42b269cc138feb7bc781e.
- 20261006170540 — vne_id_trace_links. SHA-256: ac9643bd381f20c2a228e643c260ebeb078225224c8a0579d286d62725a6fa18.

Первая миграция создаёт закрытую финальную структуру необходимых доменных объектов: 22 таблицы и 40 private-функций. Все таблицы защищены RLS. Нет клиентских прав на таблицы, колонки, последовательности и функции для anon/authenticated/service_role; нет public RPC, активных политик, Auth-trigger, реального owner или seed. Схемы auth/storage не изменялись.

Вторая миграция добавляет ровно три nullable UUID-поля без defaults/backfill:
- public.application_events.correlation_id
- private.ticket_events.correlation_id
- private.ticket_events.operation_id

Созданы четыре индекса для trace. Обновлены log_app, log_app2, ticket_issue, ticket_admin, ticket_scan. Оба журнала заявок и outbox получают одинаковый correlation_id. IssuanceId — строковый alias ID события выдачи. Повтор actor+operation возвращает исходные идентификаторы; старые операции без trace не получают выдуманную связь. bigint передаётся строкой. Staff-only поля не добавлены в публичный ticket DTO.

Read-back подтвердил поля, индексы, права/RLS и точное совпадение MD5 исходных тел всех пяти изменённых функций с SQL-пакетом. Миграции присутствуют в истории Supabase.

## Проверки

- PASS: восстановление финальных определений в одноразовом PGlite 0.3.14.
- PASS: baseline + ID SQL в новом пустом PGlite.
- PASS: независимая проверка при широких исходных default privileges; итоговый доступ API-ролей закрыт.
- PASS: оба log_app helpers, issue/replay/conflict, изоляция actor, checkin/replay, revoke/replay/noop, неизвестный token без фиктивного pass_id, отсутствующий event, legacy NULL trace, отсутствие неавторизованной выдачи.
- PASS: issuanceId больше 2^53 сохраняется точно как строка.
- PASS: локальный issuer сохраняет trace-поля, логирует только allowlist, не пишет синтетические PII/JWT/token/secret-маркеры и не ломает успешный ответ при отказе log sink.
- Managed Supabase: проверены genuine auth/pgcrypto prerequisites; после apply выполнено чтение metadata, не гостевых записей.

PGlite не доказывает managed Auth/MFA, PostgREST или конкурентность двух независимых соединений. Функциональные записи делались только в одноразовом локальном PGlite с синтетическими identities, не в выбранной Supabase-базе.

## Advisor

Security: 22 INFO о RLS без политик, ожидаемые для намеренно закрытого тестового каркаса; ERROR/WARN не возвращены. Не включать политики ради удаления этого сообщения. Документация: https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy .

Performance: 14 INFO о foreign keys без covering index, унаследованных от базовой схемы, и 15 INFO unused indexes в новой неиспользуемой базе. Это не повод удалять trace-indexes. Дополнительная оптимизация в этот минимальный ID-патч не включена. Документация: https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys и https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index .

## Граница готовности

Это закрытый тестовый каркас. Сайт к нему не подключён. API-права, Auth hooks, production deploy, внешние уведомления, реальные платежи, учётные записи и выдача реальных билетов не включались. Подготовленный issuer-handler.patch проверен локально, но не deployed. GitHub-публикация — отдельный шаг и здесь не заявлена выполненной.

Будущее включение конкретных RPC/ACL/Auth hooks требует отдельного рассмотрения и разрешения на точное расширение доступа. До подключения сайта нужны managed integration tests и отдельная проверка конкурентности.

## Важное правило использования файлов

Эти две миграции относятся к НОВОЙ тестовой истории. Нельзя просто дописать restricted baseline после 26 старых миграций в исходном архиве и затем запускать весь каталог: это повторное создание уже существующих объектов. Хранить как отдельный deployment/test пакет; существующий архив сохранить неизменным. Историю production они не заменяют.

Файлы сначала созданы штатным Supabase CLI 2.119.0; после MCP apply имена локальных файлов согласованы с реальными версиями из migration history. SQL-байты не менялись. Новые имена: 20261006170437_vne_restricted_test_baseline.sql и 20261006170540_vne_id_trace_links.sql.
