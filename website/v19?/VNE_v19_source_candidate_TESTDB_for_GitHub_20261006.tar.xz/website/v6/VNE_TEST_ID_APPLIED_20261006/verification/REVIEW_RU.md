# Независимая техническая проверка
2026-10-06: APPROVE для точных файлов restricted TEST baseline + ID extension.
Проверены отсутствие seeds/старого owner-backfill/Auth-trigger/storage-изменений/новых credentials; RLS на 22 таблицах; закрытые effective table/column/sequence/function privileges API-ролей; отсутствие public RPC и лишней зависимости event_private_details. SQL независимо воспроизведён на свежем PGlite с широкими исходными default privileges. После применения в managed Supabase проверены поля, индексы, ACL/RLS, migration history и тела пяти функций.
Baseline SHA-256: a6f2a6b0266634fad7563f78ef396a5f2522a35429b42b269cc138feb7bc781e
ID extension SHA-256: ac9643bd381f20c2a228e643c260ebeb078225224c8a0579d286d62725a6fa18
Область одобрения: закрытая тестовая структура и три поля со связанными private-writers. Включение доступа, сайта, Auth hooks, issuer deployment и production не входит.
