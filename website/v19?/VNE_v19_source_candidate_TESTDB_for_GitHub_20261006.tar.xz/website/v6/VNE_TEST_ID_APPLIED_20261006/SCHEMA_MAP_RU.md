# Карта идентификаторов

Канонические ID используются повторно: auth.users.id = profiles.id; applications.id; events.id; reservations.id; orders.id; payments.id; participations.id; private.ticket_passes.id. Новый параллельный UUID для них не добавлен.

Три новых поля: application_events.correlation_id; private.ticket_events.correlation_id; private.ticket_events.operation_id. Все uuid NULL без default.

correlation_id связывает журналы одной логической операции. Для заявки log_app/log_app2 записывают его в application_events, audit_log и payload outbox. Для issue/revoke/checkin ticket_events и audit_log используют один UUID; verify хранит собственную trace без выдачи.

operation_id — существующий ключ идемпотентной команды в области actor + operation; поле журнала не UNIQUE и не FK к успешным операциям. Повтор команды сохраняет первоначальную trace.

issuanceId — строковое представление существующего bigint ticket_events.id для action=issue, только в защищённом служебном ответе. Отдельной физической колонки issuance_id нет. Отображение QR/capability и права доступа не менялись.

Схема на PNG иллюстративная; это не скриншот Supabase и не доказательство подключения сайта.
