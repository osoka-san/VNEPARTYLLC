import {PGlite} from '@electric-sql/pglite';
import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {randomUUID as id,randomBytes,createHash} from 'node:crypto';
const db=new PGlite();const q=async(s,p)=>(await db.query(s,p)).rows;

const stub=(await readFile(new URL('./local-supabase-stub.sql',import.meta.url),'utf8')).replace('create extension if not exists pgcrypto with schema extensions;','');
await db.exec(stub);await db.exec(`alter table auth.users add column email_confirmed_at timestamptz,add column raw_user_meta_data jsonb default '{}';`);
await db.exec('begin;'+await readFile(new URL('../migrations/20261006170437_vne_restricted_test_baseline.sql',import.meta.url),'utf8')+'commit;');
// ACL evidence before/after ID replacement. No grants are enabled even in this test.
const acl=()=>q(`select n.nspname,c.relname,r.rolname,has_table_privilege(r.oid,c.oid,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER') as allowed from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r where c.relkind='r' and n.nspname in ('public','private') and r.rolname in ('anon','authenticated','service_role')`);
assert.ok((await acl()).every(r=>!r.allowed));
await db.exec('begin;'+await readFile(new URL('../migrations/20261006170540_vne_id_trace_links.sql',import.meta.url),'utf8')+'commit;');
assert.ok((await acl()).every(r=>!r.allowed));
assert.equal((await q(`select count(*)::int n from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join pg_roles r where n.nspname='private' and r.rolname in ('anon','authenticated','service_role') and has_function_privilege(r.oid,p.oid,'EXECUTE')`))[0].n,0);
assert.equal((await q(`select count(*)::int n from pg_attribute a join pg_class c on c.oid=a.attrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname in ('public','private') and a.attacl is not null`))[0].n,0);
console.log('PASS restricted table, function and column ACLs survive ID replacements');
const actor=id(),actor2=id(),session=id(),session2=id(),event=id(),app=id();
for(const [a,s] of [[actor,session],[actor2,session2]]){
 await q('insert into auth.users(id,email,email_confirmed_at) values($1,$2,now())',[a,a+'@synthetic.invalid']);
 await q('insert into auth.sessions(id,user_id,not_after) values($1,$2,now()+interval \'1 day\')',[s,a]);
 await q("insert into private.member_admission(user_id,state,source) values($1,'admitted','isolated-test')",[a]);
 await q("insert into public.staff_assignments(user_id,role) values($1,'owner')",[a]);
}
const as=async(a=actor,s=session)=>q("select set_config('request.jwt.claims',$1,false)",[JSON.stringify({sub:a,session_id:s,role:'authenticated',aal:'aal2'})]);await as();
await q("insert into public.events(id,slug,title,status,capacity,starts_at,entry_opens_at,entry_closes_at,qr_release_at,is_synthetic) values($1,$2,'SYNTHETIC','published',10,now()+interval '10 minutes',now()-interval '1 minute',now()+interval '1 hour',now()-interval '2 minutes',false)",[event,event]);
await q('insert into public.applications(id,event_id,user_id) values($1,$2,$3)',[app,event,actor]);
for(const fn of ['log_app','log_app2']){
 const sql=fn==='log_app'?`select private.log_app($1,null,'submitted','synthetic',$2)`:`select private.log_app2($1,'submitted','needs_info','synthetic','reply',$2)`;
 await q(sql,[app,'test.'+fn]);
 const a=(await q('select correlation_id from public.application_events where application_id=$1 order by id desc limit 1',[app]))[0];
 const b=(await q('select correlation_id from private.audit_log where action=$1',['test.'+fn]))[0];
 const c=(await q('select payload,status from private.outbox order by id desc limit 1'))[0];
 assert.equal(a.correlation_id,b.correlation_id);assert.equal(a.correlation_id,c.payload.correlation_id);assert.equal(c.status,'held');
}console.log('PASS both application writers share correlation with audit/outbox');
await db.exec('alter sequence private.ticket_events_id_seq restart with 9007199254740993');
const hash=x=>createHash('sha256').update(x).digest('hex');
const make=()=>({pass:id(),operation:id(),token:randomBytes(32).toString('base64url'),view:randomBytes(32).toString('base64url'),input:{eventId:event,name:'SYNTHETIC PII',access:'GENERAL',reason:'SYNTHETIC REASON'}});
const issue=async(s)=>(await q(`select private.ticket_issue($1::jsonb,$2,$3,$4,'test-v1',$5) result`,[JSON.stringify(s.input),s.pass,hash(s.view),hash(s.token),s.operation]))[0].result;
const scan=async(body)=>(await q('select private.ticket_scan($1::jsonb) result',[JSON.stringify(body)]))[0].result;
const admin=async(action,body)=>(await q('select private.ticket_admin($1,$2::jsonb) result',[action,JSON.stringify(body)]))[0].result;
const spec=make(),first=await issue(spec),again=await issue({...spec,pass:id()});
assert.equal(first.issuanceId,'9007199254740993');assert.equal(first.issuanceId,again.issuanceId);assert.equal(first.correlationId,again.correlationId);assert.equal(first.pass.id,again.pass.id);assert.equal(again.duplicate,true);
assert.equal((await q("select count(*)::int n from private.ticket_events where operation_id=$1 and action='issue'",[spec.operation]))[0].n,1);
await assert.rejects(issue({...spec,input:{...spec.input,name:'changed'}}),/idempotency_conflict/);
const issueAudit=(await q("select correlation_id from private.audit_log where object_id=$1 and action='ticket.issue'",[spec.pass]))[0];assert.equal(issueAudit.correlation_id,first.correlationId);
console.log('PASS issue replay, conflict, shared audit trace, bigint exact string');
await as(actor2,session2);const other=await issue({...make(),operation:spec.operation});assert.notEqual(other.pass.id,first.pass.id);await as();
console.log('PASS operation ID is scoped by actor');
const read=await scan({eventId:event,token:spec.token,consume:false});assert.equal(read.outcome,'ready');assert.equal(read.operationId,null);assert.ok(read.correlationId);
const missing=await scan({eventId:event,token:randomBytes(32).toString('base64url'),consume:false});assert.equal(missing.outcome,'not_found');assert.ok(missing.correlationId);
assert.equal((await q('select pass_id from private.ticket_events where correlation_id=$1',[missing.correlationId]))[0].pass_id,null);
const absentEvent=await scan({eventId:id(),token:spec.token,consume:false});assert.equal(absentEvent.outcome,'not_found');
console.log('PASS verify, unknown token NULL pass and nonexistent event safe response');
const command={eventId:event,token:spec.token,consume:true,operationId:id(),expectedVersion:1};const checked=await scan(command),replay=await scan(command);assert.equal(checked.outcome,'accepted');assert.equal(checked.correlationId,replay.correlationId);assert.equal(replay.replayed,true);
assert.equal((await q("select correlation_id from private.audit_log where object_id=$1 and action='ticket.checkin'",[spec.pass]))[0].correlation_id,checked.correlationId);
console.log('PASS checkin replay and audit trace');
const revokeSpec=make();const issued=await issue(revokeSpec);const body={id:issued.pass.id,reason:'SYNTHETIC REVOKE',operationId:id(),expectedVersion:1};const revoked=await admin('revoke',body),revokedReplay=await admin('revoke',body);assert.equal(revoked.correlationId,revokedReplay.correlationId);assert.equal(revokedReplay.duplicate,true);
const noop=await admin('revoke',{...body,operationId:id(),expectedVersion:2});assert.ok(noop.correlationId);assert.equal((await q('select result from private.audit_log where correlation_id=$1',[noop.correlationId]))[0].result,'noop');
const history=await admin('history',{id:spec.pass});assert.ok(history.items.every(x=>typeof x.id==='string'));assert.ok(!('issuanceId' in first.pass));
console.log('PASS revoke replay/noop audit and staff history bigint strings');
// A pre-existing operation lacking trace must stay explicitly unknown, not invented.
await q('update private.ticket_events set operation_id=null,correlation_id=null where actor=$1 and operation_id=$2',[actor,revokeSpec.operation]);const legacy=await issue(revokeSpec);assert.equal(legacy.issuanceId,null);assert.equal(legacy.correlationId,null);
console.log('PASS legacy replay keeps unknown trace NULL');
await q("select set_config('request.jwt.claims','{}',false)");await assert.rejects(issue(make()),/forbidden/);
console.log('PASS internal writer still denies unauthenticated request');
console.log('ALL PASS: isolated synthetic tests, no managed Supabase access or external actions');await db.close();
