# Локальные тесты
Node.js 24.19.0. Из корня пакета: npm ci --ignore-scripts, затем npm test.
Тест создаёт одноразовый PGlite с локальными Auth-stubs и синтетическими identities. Никаких подключений к Supabase, доставки или платежей. НЕ запускайте local-supabase-stub.sql в Supabase.
Private functions проверяются с синтетическими JWT claims под владельцем одноразовой локальной базы. Это проверка SQL-предикатов; managed Auth/MFA/PostgREST и две независимые сессии не эмулируются. Реальные API-права тестовой базы закрыты.
