// Original static recovery document: no request/error values, scripts or remote resources.
export function statusFallback(code = 500) {
  const status = Number.isInteger(code) && code >= 500 && code <= 599 ? code : 500;
  const digits = {
    '0':['01110','11011','11011','11011','11011','11011','01110'],
    '1':['00110','01110','00110','00110','00110','00110','01111'],
    '2':['11110','00011','00011','01110','11000','11000','11111'],
    '3':['11110','00011','00011','01110','00011','00011','11110'],
    '4':['11011','11011','11011','11111','00011','00011','00011'],
    '5':['11111','11000','11000','11110','00011','00011','11110'],
    '6':['01110','11000','11000','11110','11011','11011','01110'],
    '7':['11111','00011','00011','00110','01100','01100','01100'],
    '8':['01110','11011','11011','01110','11011','11011','01110'],
    '9':['01110','11011','11011','01111','00011','00011','01110'],
  };
  const tiles = String(status).split('').flatMap((digit,d)=>digits[digit].flatMap((row,y)=>[...row].flatMap((cell,x)=>cell==='1'?[`<rect x="${20+d*132+x*20}" y="${20+y*20}" width="16" height="16" rx="2" style="animation-delay:${(6-y)*22+d*60+x*12}ms"/>`]:[]))).join('');
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>ВНЕ · ${status}</title><style>body{margin:0;min-height:100dvh;display:grid;place-items:center;background:#111512;color:#eff4ef;font:16px/1.6 system-ui,sans-serif}main{box-sizing:border-box;width:min(620px,100%);padding:32px 24px;text-align:center}svg{width:min(410px,100%);height:auto;margin:20px auto;display:block;overflow:hidden}rect{fill:#ff956f;animation:settle .8s ease-out backwards}@keyframes settle{from{transform:translateY(-35px);opacity:.1}to{transform:translateY(0);opacity:1}}@media(prefers-reduced-motion:reduce){rect{animation:none}}h1{font-size:clamp(26px,6vw,38px);line-height:1.2;font-weight:500}p{color:#a6b2a8}nav{display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin-top:25px}a{padding:11px 17px;border:1px solid #536959;border-radius:7px;color:#c1f5c5;text-decoration:none}a:focus-visible{outline:3px solid #eff4ef;outline-offset:4px}.eyebrow{font-size:11px;letter-spacing:.14em}</style></head><body><main><p class="eyebrow">ВНЕ / ВОССТАНОВЛЕНИЕ</p><svg viewBox="0 0 400 180" aria-hidden="true">${tiles}</svg><p>HTTP ${status}</p><h1>${status === 500 ? 'Что-то пошло не так' : 'Сервис временно недоступен'}</h1><p>Страницу не удалось загрузить. Попробуйте вернуться позже или начать с главной.</p><nav aria-label="Восстановление"><a href="/">На главную</a><a href="/admin">Диагностика</a></nav></main></body></html>`;
}
