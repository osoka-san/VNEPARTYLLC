// Builds genuine public v22 React routes in an isolated frontend-only variant.
import {cp,mkdir,readFile,writeFile,rm,symlink} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const root=process.cwd(), work=path.join(root,'.sites-runtime/classic-preview');
const manifest=JSON.parse(await readFile('.openai/hosting.json','utf8'));
if(manifest.project_id!=='appgprj_6ac74b7bfbe88191a82f308a0955e849'||manifest.d1||manifest.r2)throw Error('Wrong isolated preview');
await rm(work,{recursive:true,force:true}); await mkdir(work,{recursive:true});
for(const name of ['src','public','package.json','bun.lock','bunfig.toml','tsconfig.json','vite.config.ts'])await cp(name,path.join(work,name),{recursive:true});
await symlink(path.join(root,'node_modules'),path.join(work,'node_modules'),'dir');
const routes=['__root.tsx','index.tsx','about.tsx','events.tsx','events.index.tsx','events.$slug.tsx','faq.tsx','rules.tsx','contact.tsx','privacy.tsx','consent.tsx','terms.tsx','refunds.tsx','cookies.tsx'];
await rm(path.join(work,'src/routes'),{recursive:true});await mkdir(path.join(work,'src/routes'));
for(const file of routes)await cp(path.join(root,'src/routes',file),path.join(work,'src/routes',file));
await rm(path.join(work,'src/routeTree.gen.ts'),{force:true});
// Same public components and performance code. Unsupported flows are explicit and inert.
for(const route of ['apply','member','login','pass','scan'])await writeFile(path.join(work,'src/routes',route+'.tsx'),`import {createFileRoute} from '@tanstack/react-router';import {PageShell} from '@/components/app/PageShell';export const Route=createFileRoute('/${route}')({validateSearch:(s:Record<string,unknown>)=>({event:typeof s['event']==='string'?s['event']:undefined}),component:()=> <PageShell eyebrow="ВНЕ / тест интерфейса v22" title="В этом превью раздел отключён" intro="Здесь проверяются публичные страницы, старое меню и оптимизация загрузки. Вход, анкеты, кабинет, QR и административные действия в этом отдельном превью не работают." density="compact"><p className="mx-auto max-w-3xl px-5 py-10"><a href="/">Вернуться на главную</a></p></PageShell>});`);
// Preview-only original diagnostics, never the operational admin implementation.
await cp(path.join(root,'preview-v22/ui'),path.join(work,'src/components/preview-observatory'),{recursive:true});
await writeFile(path.join(work,'src/routes/admin.tsx'),`import {createFileRoute} from '@tanstack/react-router';import {Observatory} from '@/components/preview-observatory/Observatory';export const Route=createFileRoute('/admin')({component:Observatory});`);
let shell=await readFile(path.join(work,'src/routes/__root.tsx'),'utf8');
shell = `import {StatusScene} from '@/components/preview-observatory/StatusScene';
import {ClientTelemetry} from '@/components/preview-observatory/ClientTelemetry';
import {recordBrowserEvent} from '@/components/preview-observatory/telemetry';
` + shell;
const fallbackPattern = /function NotFoundComponent\(\) \{[\s\S]*?export const Route/g;
if([...shell.matchAll(fallbackPattern)].length!==1)throw Error('Expected exactly one preview error-boundary replacement');
shell = shell.replace(/function NotFoundComponent\(\) \{[\s\S]*?export const Route/, `function NotFoundComponent() {
  useEffect(() => { recordBrowserEvent('route_missing', 'fallback'); }, []);
  return <StatusScene code={404} />;
}
function ErrorComponent({ reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  useEffect(() => { recordBrowserEvent('render_failed', 'fallback'); }, []);
  return <StatusScene code={500} onRetry={() => { router.invalidate(); reset(); }} />;
}
export const Route`);
shell = shell.replace('<SiteLoadingProvider>', '<ClientTelemetry /><SiteLoadingProvider>');
shell=shell.replace('const admin = isAdminPath(pathname);','const admin = false; // No admin runtime in this frontend-only preview.');
shell=shell.replace('<UtilityDock />','<aside style={{position:"fixed",left:8,bottom:76,zIndex:31,maxWidth:"calc(100vw - 16px)",background:"#111",color:"#ddd",padding:"6px 10px",fontSize:11,borderRadius:6}} aria-label="Режим просмотра">v22 · старое меню · тест интерфейса · без заявок · <a href="/admin">Диагностика</a> · <a href="/preview-login">Вход / выход</a></aside><UtilityDock />');
shell=shell.replace('{ name: "author", content: "ВНЕ" },','{ name: "author", content: "ВНЕ" }, { name: "robots", content: "noindex, nofollow" },');
await writeFile(path.join(work,'src/routes/__root.tsx'),shell);
// No database/client calls: source defaults, same documented fallback values.
await writeFile(path.join(work,'src/lib/media.functions.ts'),`export async function getMediaOverrides(){return {};}`);
await writeFile(path.join(work,'src/lib/sections.functions.ts'),`export async function getPublishedSections(_input:{data:{keys:string[]}}):Promise<Record<string,{title:string;body:string}>>{return {};}`);
// Exclude operational admin implementation from reachable graph.
await writeFile(path.join(work,'src/components/admin/AdminNavigation.tsx'),`export function AdminNavigation(){return null;}`);
await writeFile(path.join(work,'src/components/admin/AdminSettingsFooter.tsx'),`export function AdminSettingsFooter(){return null;}`);
// Explicit environment allowlist prevents accidental backend-key injection by Vite.
const env={};for(const key of ['PATH','HOME','TMPDIR','TEMP','TMP','NODE_ENV','CI'])if(process.env[key])env[key]=process.env[key];
const result=spawnSync('node',[path.join(root,'node_modules/vite/bin/vite.js'),'build'],{cwd:work,stdio:'inherit',env});
if(result.status!==0)process.exit(result.status??1);
await rm(path.join(root,'.output'),{recursive:true,force:true});await cp(path.join(work,'.output'),path.join(root,'.output'),{recursive:true});
