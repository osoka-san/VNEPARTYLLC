import {statusFallback} from './status-fallback.mjs';
const pages=new Set(['/','/about','/events','/faq','/rules','/contact','/privacy','/consent','/terms','/refunds','/cookies','/apply','/member','/admin','/login','/pass','/scan']);
function discard(response){try{void response.body?.cancel().catch(()=>{});}catch{}}
const headers={'Cache-Control':'private, no-store','X-Robots-Tag':'noindex, nofollow','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};
export default function guard(worker,assetPaths=new Set()){return{async fetch(request,env,ctx){
 const url=new URL(request.url);const navigation=/^\/[a-z0-9/-]{0,180}$/.test(url.pathname)&&!/^\/(api|_serverFn|assets|fonts|media|loading|brand)(\/|$)/.test(url.pathname);if(!['GET','HEAD'].includes(request.method))return new Response('Frontend preview is read-only',{status:405,headers});
 if(url.pathname.includes('%')||url.pathname.includes('\\'))return new Response('Unavailable',{status:404,headers});
 if(url.pathname.startsWith('/api/')||url.pathname.startsWith('/_serverFn/')||(!navigation&&!pages.has(url.pathname)&&!/^\/events\/[a-z0-9-]+\/?$/.test(url.pathname)&&!/^\/(assets|fonts|media|loading|brand)\/[A-Za-z0-9_./-]+$/.test(url.pathname)&&!/^\/(favicon\.ico|icon\.svg|apple-touch-icon\.png|icon-192\.png|icon-512\.png|og-cover\.jpg|robots\.txt)$/.test(url.pathname)))return new Response('Unavailable in frontend preview',{status:404,headers});
 // Only emitted files may bypass login; missing assets must never reach SSR.
 if(!navigation&&!pages.has(url.pathname)&&!/^\/events\/[a-z0-9-]+\/?$/.test(url.pathname)&&!assetPaths.has(url.pathname))return new Response(request.method==='HEAD'?null:'Asset not found',{status:404,headers:{...headers,'Content-Type':'text/plain; charset=utf-8'}});
 const staticAsset=assetPaths.has(url.pathname);
 if(staticAsset&&typeof env?.ASSETS?.fetch!=='function')return new Response(request.method==='HEAD'?null:'Static assets unavailable',{status:503,headers:{...headers,'Content-Type':'text/plain; charset=utf-8'}});
 let result;try{result=staticAsset?await env.ASSETS.fetch(request):await worker.fetch(request,{ASSETS:env?.ASSETS},ctx);}catch{if(staticAsset)return new Response(request.method==='HEAD'?null:'Static assets unavailable',{status:503,headers:{...headers,'Content-Type':'text/plain; charset=utf-8'}});return new Response(request.method==='HEAD'?null:statusFallback(500),{status:500,headers:{...headers,'Content-Type':'text/html; charset=utf-8'}});}
 if(!staticAsset&&result.status>=500){discard(result);return new Response(request.method==='HEAD'?null:statusFallback(result.status),{status:result.status,headers:{...headers,'Content-Type':'text/html; charset=utf-8'}});}
 if(staticAsset&&(result.status>=400||result.headers.get('content-type')?.toLowerCase().includes('text/html'))){discard(result);return new Response(request.method==='HEAD'?null:'Asset not found',{status:404,headers:{...headers,'Content-Type':'text/plain; charset=utf-8'}});}
 if(request.method==='HEAD')discard(result);
 const h=new Headers(result.headers);for(const[k,v]of Object.entries(headers))h.set(k,v);h.delete('Set-Cookie');return new Response(request.method==='HEAD'?null:result.body,{status:result.status,statusText:result.statusText,headers:h});
}}}
