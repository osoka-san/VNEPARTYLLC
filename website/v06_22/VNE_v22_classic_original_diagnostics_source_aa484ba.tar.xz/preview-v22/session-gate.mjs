// Existing TEST Supabase SSR cookie transport, narrowed to one preview account.
// No role checks/grants, database calls, password management, or data access.
import {createServerClient,parseCookieHeader,serializeCookieHeader} from '@supabase/ssr';
import {performSignIn} from '../src/lib/auth/auth-core.ts';
export const ORIGIN='https://vne-v22-classic-test.can-avci48.chatgpt.site';
export const AUTH_ORIGIN='https://xrocuwlofxhxoxajukne.supabase.co';
export const ADMIN_ID='02e03845-bc0d-4a9b-8500-87bb1f11ccf6';
const CSRF='__Host-vne-preview-csrf';
const cookieOptions={path:'/',secure:true,httpOnly:true,sameSite:'strict'};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function context(request,env){const jar=new Map(parseCookieHeader(request.headers.get('cookie')??'').map(c=>[c.name,c.value??''])),pending=new Map();const client=createServerClient(AUTH_ORIGIN,env.VNE_SUPABASE_PUBLISHABLE_KEY,{cookies:{getAll:()=>[...jar].map(([name,value])=>({name,value})),setAll(items){for(const c of items){pending.set(c.name,c);if(!c.value||c.options?.maxAge===0)jar.delete(c.name);else jar.set(c.name,c.value);}}},cookieOptions:{name:'sb-vne-v22-preview-auth',path:'/',secure:true,httpOnly:true,sameSite:'lax'}});return{client,jar,pending};}
function response(body,status=200,ctx=null,extra={}){const h=new Headers({'Content-Type':'text/html; charset=utf-8','Cache-Control':'private, no-store','Vary':'Cookie','X-Robots-Tag':'noindex, nofollow','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',...extra});for(const c of ctx?.pending.values()??[])h.append('Set-Cookie',serializeCookieHeader(c.name,c.value,{...c.options,path:'/',secure:true,httpOnly:true,sameSite:'lax'}));return new Response(body,{status,headers:h});}
function csrf(ctx){let token=ctx.jar.get(CSRF);if(!/^[a-f0-9]{64}$/.test(token??'')){token=Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');ctx.jar.set(CSRF,token);ctx.pending.set(CSRF,{name:CSRF,value:token,options:{...cookieOptions,maxAge:3600}});}return token;}
function login(ctx,message='',connected=false,status=200){const token=csrf(ctx);return response(`<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ВНЕ v22 · вход ADMIN_TEST</title><style>body{margin:0;background:#101110;color:#f6f6ed;font:16px system-ui,sans-serif;display:grid;min-height:100dvh;place-items:center}main{width:min(380px,calc(100vw - 48px));padding:24px}h1{font-size:28px}label{display:block;margin-top:20px}input,button{box-sizing:border-box;width:100%;min-height:48px;padding:12px;font:inherit;border-radius:6px;border:1px solid #777}input{margin-top:8px;background:#222;color:white}button{margin-top:24px;background:#ff7041;color:#111;cursor:pointer}a{color:#baf4bf}.note{color:#aaa;font-size:14px;line-height:1.5}</style><main><p>ВНЕ / тест интерфейса v22</p><h1>${connected?'Вы вошли в превью':'Вход ADMIN_TEST'}</h1><p class="note">Старое меню и исходный шрифт. Здесь нет рабочих заявок, кабинетов, QR или административных действий.</p>${message?`<p role="alert">${esc(message)}</p>`:''}${connected?`<p><a href="/">Открыть сайт</a></p><form method="post" action="/preview-logout"><input type="hidden" name="csrf" value="${token}"><button>Выйти</button></form>`:`<form method="post" action="/preview-login"><input type="hidden" name="csrf" value="${token}"><label>Логин<input name="identifier" autocomplete="username" value="ADMIN_TEST" required maxlength="254"></label><label>Пароль<input name="password" type="password" autocomplete="current-password" required maxlength="1024"></label><button>Войти</button></form>`}</main></html>`,status,ctx,{'Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",'X-Frame-Options':'DENY'});}
async function allowed(ctx){try{const{data,error}=await ctx.client.auth.getUser();return !error&&data.user?.id===ADMIN_ID&&data.user.is_anonymous===false;}catch{return false;}}
async function readForm(request){const reader=request.body?.getReader();if(!reader)return null;const parts=[];let size=0;while(true){const{done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8192){await reader.cancel();return null;}parts.push(value);}const body=new Uint8Array(size);let offset=0;for(const p of parts){body.set(p,offset);offset+=p.length;}return new URLSearchParams(new TextDecoder().decode(body));}
export default function gate(worker,createContext=context){return{async fetch(request,env,execution){const u=new URL(request.url);if(u.origin!==ORIGIN||env.VNE_SUPABASE_URL!==AUTH_ORIGIN||!/^sb_publishable_[A-Za-z0-9_-]+$/.test(env.VNE_SUPABASE_PUBLISHABLE_KEY??'')||env.VNE_PREVIEW_AUTH!=='admin-test-only')return response('Превью временно недоступно',503);
 if(u.pathname.includes('%')||u.pathname.includes('\\'))return response('Недоступно',404);
 const isLogin=u.pathname==='/preview-login',isLogout=u.pathname==='/preview-logout';
 // Public immutable assets contain only compiled public interface/fonts/images, no session or PII.
 const asset=/^\/(assets|fonts|media|loading|brand)\/[A-Za-z0-9_./-]+$/.test(u.pathname)||/^\/(favicon\.ico|icon\.svg|apple-touch-icon\.png|icon-192\.png|icon-512\.png|og-cover\.jpg|robots\.txt)$/.test(u.pathname);
 if(asset&&['GET','HEAD'].includes(request.method))return worker.fetch(request,{ASSETS:env.ASSETS},execution);
 if(!['GET','HEAD'].includes(request.method)&&!(request.method==='POST'&&(isLogin||isLogout)))return response('Действие недоступно',405);
 const ctx=createContext(request,env);
 if(request.method==='POST'){
  if(request.headers.get('origin')!==ORIGIN||request.headers.get('sec-fetch-site')==='cross-site')return response('Запрос отклонён',403);
  if(request.headers.get('content-type')?.split(';')[0].trim()!=='application/x-www-form-urlencoded')return response('Неверный формат',415);
  const form=await readForm(request).catch(()=>null);if(!form)return response('Запрос слишком большой',413);
  const token=ctx.jar.get(CSRF);if(!token||form.get('csrf')!==token||!/^[a-f0-9]{64}$/.test(token))return response('Обновите страницу входа',403);
  if(isLogout){try{await ctx.client.auth.signOut({scope:'local'});}catch{}for(const [name]of ctx.jar)if(name.startsWith('sb-vne-v22-preview-auth'))ctx.pending.set(name,{name,value:'',options:{maxAge:0}});return response(null,303,ctx,{Location:'/preview-login'});}
  const input=(form.get('identifier')??'').trim();const email=input.toUpperCase()==='ADMIN_TEST'?'savik3003@gmail.com':input.toLowerCase();
  // No other account can mint a session at this origin.
  if(email!=='savik3003@gmail.com')return login(ctx,'Не удалось войти. Проверьте логин и пароль.',false,401);
  const result=await performSignIn(ctx.client,{email,password:form.get('password'),redirect:'/'});
  if(result.ok&&await allowed(ctx))return response(null,303,ctx,{Location:'/'});
  // Failed/mismatched login must not leave newly issued session chunks behind.
  for(const [name]of ctx.jar)if(name.startsWith('sb-vne-v22-preview-auth'))ctx.pending.set(name,{name,value:'',options:{maxAge:0}});
  return login(ctx,'Не удалось войти. Проверьте логин и пароль.',false,401);
 }
 if(isLogout)return response('Используйте кнопку выхода',405);
 const verified=await allowed(ctx);if(isLogin){const r=login(ctx,'',verified);return request.method==='HEAD'?new Response(null,{status:r.status,headers:r.headers}):r;}
 if(!verified)return response(null,303,ctx,{Location:'/preview-login'});
 const clean=new Headers(request.headers);for(const key of [...clean.keys()])if(key==='cookie'||key==='authorization'||key.startsWith('oai-')||key.startsWith('x-vne-')||['forwarded','x-forwarded-host','x-forwarded-proto'].includes(key))clean.delete(key);
 const result=await worker.fetch(new Request(request,{headers:clean}),{ASSETS:env.ASSETS},execution);const h=new Headers(result.headers);h.set('Cache-Control','private, no-store');h.set('Vary','Cookie');h.delete('Set-Cookie');for(const c of ctx.pending.values())h.append('Set-Cookie',serializeCookieHeader(c.name,c.value,{...c.options,path:'/',secure:true,httpOnly:true,sameSite:'lax'}));return new Response(result.body,{status:result.status,statusText:result.statusText,headers:h});
}}}
