import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs/promises";
import path from "node:path";
import guard from "./guard.mjs";
import sessionGate, { ORIGIN, AUTH_ORIGIN, ADMIN_ID } from "../dist/server/session-gate.mjs";
import publicWorker from "../dist/server/index.mjs";
import publishedWorker from "../dist/server/index.js";
import { ASSET_PATHS } from "../dist/server/asset-paths.mjs";

// Run after build.mjs and prepare.mjs. All identities and bindings below are synthetic.
const env = {
  VNE_SUPABASE_URL: AUTH_ORIGIN,
  VNE_SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test_fixture",
  VNE_PREVIEW_AUTH: "admin-test-only",
};
const execution = { waitUntil() {} };
const missing = [
  "/assets/index.html",
  "/assets/nonexistent.js",
  "/fonts/index.html",
  "/fonts/nonexistent.woff2",
  "/media/nonexistent.webp",
  "/loading/nonexistent.js",
  "/brand/nonexistent.svg",
  "/assets/index.map",
  "/assets/nested/index.html",
  "/assets/nonexistent.js?x=1",
  "/assets//index.html",
];
const html =
  '<!doctype html><html><script type="module" src="/assets/bootstrap.js"></script></html>';
let contexts = 0,
  ssrCalls = 0;
const context =
  (verified = false, wrongId = false, anonymous = false) =>
  () => {
    contexts++;
    return {
      jar: new Map(),
      pending: new Map(),
      client: {
        auth: {
          getUser: async () => ({
            data: {
              user: verified
                ? { id: wrongId ? "other-fixture" : ADMIN_ID, is_anonymous: anonymous }
                : null,
            },
            error: null,
          }),
        },
      },
    };
  };
const sentinelWorker = {
  fetch: async () => {
    ssrCalls++;
    return new Response(html, {
      status: 404,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  },
};
const request = (pathname, method = "GET") => new Request(ORIGIN + pathname, { method });
const app = sessionGate(guard(sentinelWorker, ASSET_PATHS), context());

for (const method of ["GET", "HEAD"])
  for (const pathname of missing)
    test(`${method} missing asset is a plain 404 before authentication/SSR: ${pathname}`, async () => {
      const before = { contexts, ssrCalls };
      const result = await app.fetch(request(pathname, method), env, execution);
      assert.equal(result.status, 404);
      assert.equal(result.headers.get("content-type"), "text/plain; charset=utf-8");
      assert.equal(result.headers.get("x-content-type-options"), "nosniff");
      assert.equal(result.headers.get("cache-control"), "private, no-store");
      const body = await result.text();
      assert.equal(body, method === "HEAD" ? "" : "Asset not found");
      assert(!body.includes("<html") && !body.includes('type="module"'));
      assert.deepEqual({ contexts, ssrCalls }, before);
    });

test("the deploy entrypoint includes the allowlist and blocks missing asset fallback", async () => {
  const r = await publishedWorker.fetch(request("/assets/index.html"), env, execution);
  assert.equal(r.status, 404);
  assert.equal(await r.text(), "Asset not found");
});

test("a guard without an inventory fails closed for asset-like paths", async () => {
  const before = ssrCalls;
  const r = await guard(sentinelWorker).fetch(request("/assets/known.js"), {}, {});
  assert.equal(r.status, 404);
  assert.equal(ssrCalls, before);
});

const knownAsset = [...ASSET_PATHS].find((p) => p.startsWith("/assets/") && p.endsWith(".js"));

for (const method of ["GET", "HEAD"]) {
  test(`${method} known asset with missing/invalid ASSETS binding fails closed without SSR`, async () => {
    const before = { contexts, ssrCalls };
    for (const ASSETS of [undefined, {}, { fetch: null }, { fetch: "not-callable" }]) {
      const r = await app.fetch(request(knownAsset, method), { ...env, ASSETS }, execution);
      assert.equal(r.status, 503);
      assert.equal(r.headers.get("content-type"), "text/plain; charset=utf-8");
      assert.equal(await r.text(), method === "HEAD" ? "" : "Static assets unavailable");
    }
    assert.deepEqual({ contexts, ssrCalls }, before);
  });
  for (const [status, contentType] of [
    [200, "text/html; charset=utf-8"],
    [404, "text/html"],
    [500, "text/plain"],
    [200, "Text/Html"],
  ]) {
    test(`${method} known asset ASSETS ${status} ${contentType} never exposes HTML or falls through to SSR`, async () => {
      const before = { contexts, ssrCalls };
      let assetCalls = 0;
      const ASSETS = {
        fetch: async () => {
          assetCalls++;
          return new Response(html, {
            status,
            headers: { "Content-Type": contentType, "Set-Cookie": "fixture=discard" },
          });
        },
      };
      const r = await app.fetch(request(knownAsset, method), { ...env, ASSETS }, execution);
      assert.equal(r.status, 404);
      assert.equal(r.headers.get("content-type"), "text/plain; charset=utf-8");
      assert.equal(await r.text(), method === "HEAD" ? "" : "Asset not found");
      assert.equal(r.headers.get("set-cookie"), null);
      assert.equal(assetCalls, 1);
      assert.deepEqual({ contexts, ssrCalls }, before);
    });
  }
}

test("known asset GET/HEAD use only ASSETS, never authentication or SSR", async () => {
  const before = { contexts, ssrCalls };
  let assetCalls = 0;
  const ASSETS = {
    fetch: async (req) => {
      assetCalls++;
      assert.equal(new URL(req.url).pathname, knownAsset);
      return new Response("synthetic-js", {
        headers: { "Content-Type": "text/javascript", "Set-Cookie": "fixture=discard" },
      });
    },
  };
  for (const method of ["GET", "HEAD"]) {
    const r = await app.fetch(request(knownAsset, method), { ...env, ASSETS }, execution);
    assert.equal(r.status, 200);
    assert.equal(await r.text(), method === "HEAD" ? "" : "synthetic-js");
    assert.equal(r.headers.get("set-cookie"), null);
  }
  assert.equal(assetCalls, 2);
  assert.deepEqual({ contexts, ssrCalls }, before);
});

test("emitted inventory excludes HTML, maps, hidden and hosting metadata", () => {
  assert(ASSET_PATHS.size > 10);
  for (const asset of ASSET_PATHS) {
    assert(!/\.(html?|map)$/i.test(asset));
    assert(!asset.split("/").some((part) => part.startsWith(".") || part.startsWith("_")));
  }
  assert(!ASSET_PATHS.has("/_headers"));
  assert(!ASSET_PATHS.has("/assets/index.html"));
});

const assetPattern = /^\/(assets|fonts|media|loading|brand)\/[A-Za-z0-9_./-]+$/;
const rootAssetPattern =
  /^\/(favicon\.ico|icon\.svg|apple-touch-icon\.png|icon-192\.png|icon-512\.png|og-cover\.jpg|robots\.txt)$/;
const contentType = (file) =>
  ({
    ".js": "text/javascript",
    ".css": "text/css",
    ".woff2": "font/woff2",
    ".avif": "image/avif",
    ".webp": "image/webp",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".svg": "image/svg+xml",
  })[path.extname(file)] || "application/octet-stream";
let assetRequests = 0;
const ASSETS = {
  async fetch(req) {
    assetRequests++;
    const pathname = new URL(req.url).pathname;
    assert(ASSET_PATHS.has(pathname));
    const bytes = await fs.readFile("dist/client" + pathname);
    return new Response(req.method === "HEAD" ? null : bytes, {
      headers: { "Content-Type": contentType(pathname) },
    });
  },
};

test("every previously allowed emitted asset is still served byte-for-byte via the real compiled worker", async () => {
  const real = publishedWorker;
  let tested = 0;
  for (const pathname of ASSET_PATHS) {
    if (!assetPattern.test(pathname) && !rootAssetPattern.test(pathname)) continue;
    const result = await real.fetch(request(pathname), { ...env, ASSETS }, execution);
    assert.equal(result.status, 200, pathname);
    assert.deepEqual(
      Buffer.from(await result.arrayBuffer()),
      await fs.readFile("dist/client" + pathname),
      pathname,
    );
    tested++;
  }
  assert(tested > 10);
  assert.equal(assetRequests, tested);
  console.log(`Verified ${tested} emitted public assets byte-for-byte`);
});

test("existing assets retain HEAD and query-string support", async () => {
  const pathname = [...ASSET_PATHS].find((p) => p.startsWith("/assets/") && p.endsWith(".js"));
  const real = publishedWorker;
  const get = await real.fetch(request(pathname + "?v=regression"), { ...env, ASSETS }, execution);
  assert.equal(get.status, 200);
  assert.deepEqual(
    Buffer.from(await get.arrayBuffer()),
    await fs.readFile("dist/client" + pathname),
  );
  const head = await real.fetch(request(pathname, "HEAD"), { ...env, ASSETS }, execution);
  assert.equal(head.status, 200);
  assert.equal(await head.text(), "");
});

test("anonymous HTML routes still redirect without calling SSR", async () => {
  const before = ssrCalls;
  for (const pathname of [
    "/",
    "/about",
    "/events",
    "/events/example",
    "/faq",
    "/admin",
    "/apply",
    "/member",
    "/pass",
    "/scan",
  ]) {
    const r = await app.fetch(request(pathname), env, execution);
    assert.equal(r.status, 303, pathname);
    assert.equal(r.headers.get("location"), "/preview-login");
    assert.equal(await r.text(), "");
  }
  assert.equal(ssrCalls, before);
});

test("forged cookie and identity headers do not authorize an anonymous HTML route", async () => {
  const r = await app.fetch(
    new Request(ORIGIN + "/", {
      headers: {
        cookie: "fixture=forged",
        authorization: "Bearer fixture",
        "x-vne-site-admin-access": "yes",
        "oai-site-user": "fixture",
      },
    }),
    env,
    execution,
  );
  assert.equal(r.status, 303);
  assert.equal(r.headers.get("location"), "/preview-login");
});

test("exact ADMIN identity remains required and anonymous users are denied", async () => {
  for (const create of [context(true, true), context(true, false, true)]) {
    const r = await sessionGate(guard(sentinelWorker, ASSET_PATHS), create).fetch(
      request("/"),
      env,
      execution,
    );
    assert.equal(r.status, 303);
  }
});

test("authenticated API/serverFn calls and non-login writes remain blocked", async () => {
  const authApp = sessionGate(guard(sentinelWorker, ASSET_PATHS), context(true));
  const before = ssrCalls;
  for (const pathname of ["/api/health", "/_serverFn/fixture"])
    assert.equal((await authApp.fetch(request(pathname), env, execution)).status, 404);
  for (const pathname of ["/", "/assets/nonexistent.js", "/apply"])
    assert.equal((await authApp.fetch(request(pathname, "POST"), env, execution)).status, 405);
  assert.equal(ssrCalls, before);
});

test("authenticated SSR retains public pages and inert operational routes without external IO", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    throw Error("Unexpected external IO in frontend-only SSR");
  };
  try {
    const authApp = sessionGate(guard(publicWorker, ASSET_PATHS), context(true));
    for (const pathname of [
      "/",
      "/about",
      "/events",
      "/faq",
      "/rules",
      "/contact",
      "/privacy",
      "/apply",
      "/member",
      "/admin",
      "/login",
      "/pass",
      "/scan",
    ]) {
      const r = await authApp.fetch(request(pathname), { ...env, ASSETS }, execution);
      assert.equal(r.status, 200, pathname);
      const body = await r.text();
      assert(body.includes("<html"), pathname);
      assert(body.includes('type="module"'), pathname);
      if (pathname === "/admin") { assert(body.includes("Всё важное.")); assert(body.includes("Доступность серверов здесь не измеряется")); assert(!body.includes("В этом превью раздел отключён")); }
      if (["/apply", "/member", "/login", "/pass", "/scan"].includes(pathname))
        assert(body.includes("В этом превью раздел отключён"), pathname);
    }
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('unknown navigation is gated and then returns actual animated SSR 404; HEAD has no body', async () => {
  const anonymous = sessionGate(guard(publicWorker, ASSET_PATHS), context(false));
  const authenticated = sessionGate(guard(publicWorker, ASSET_PATHS), context(true));
  for (const method of ['GET','HEAD']) {
    const denied = await anonymous.fetch(request('/missing-observatory-route',method), env, execution);
    assert.equal(denied.status,303); assert.equal(denied.headers.get('location'),'/preview-login');
    assert.equal(await denied.text(),'');
    const allowed = await authenticated.fetch(request('/missing-observatory-route',method),env,execution);
    assert.equal(allowed.status,404); const body = await allowed.text();
    if(method === 'HEAD') assert.equal(body,'');
    else {assert(body.includes('vne-status-scene')); assert(body.includes('Здесь пока пусто'));}
  }
});

test('unknown operational paths do not revive private admin or APIs', async () => {
  const authenticated = sessionGate(guard(publicWorker, ASSET_PATHS), context(true));
  for(const pathname of ['/admin/applications','/admin/tickets','/api','/api/private','/_serverFn','/_serverFn/private']) {
    const r = await authenticated.fetch(request(pathname),env,execution); assert.equal(r.status,404,pathname);
    const body = await r.text(); assert(!body.includes('supabase_access_token')); assert(!body.includes('Анкеты гостей'));
  }
});

test('SSR failure uses original static recovery without revealing error details or altering HTTP status', async () => {
  for(const status of [500,502,503])for(const method of ['GET','HEAD']) {
    const broken = {fetch: async()=>new Response('person@example.com password=secret JWT=sensitive',{status,headers:{'Content-Type':'application/json','Set-Cookie':'private=hidden'}})};
    const authenticated = sessionGate(guard(broken,ASSET_PATHS),context(true));
    const response = await authenticated.fetch(request('/admin',method),env,execution);
    assert.equal(response.status,status); assert.equal(response.headers.get('set-cookie'),null);
    const body = await response.text(); if(method === 'HEAD')assert.equal(body,'');else {assert(body.includes(`HTTP ${status}`));assert(body.includes('<svg'));assert(!body.includes('secret'));assert(!body.includes('person@example.com'));}
  }
  const throwing={fetch:async()=>{throw new Error('Bearer private-token');}};
  const response=await sessionGate(guard(throwing,ASSET_PATHS),context(true)).fetch(request('/'),env,execution);
  assert.equal(response.status,500);assert(!(await response.text()).includes('private-token'));
});
