import assert from 'node:assert/strict';import {build} from 'esbuild';import {pathToFileURL} from 'node:url';import fs from 'node:fs/promises';
await fs.mkdir('.sites-runtime',{recursive:true});await build({entryPoints:['preview-v22/session-gate.mjs'],outfile:'.sites-runtime/session-test.mjs',bundle:true,format:'esm',platform:'node'});
const{default:gate,ORIGIN,AUTH_ORIGIN,ADMIN_ID}=await import(pathToFileURL(process.cwd()+'/.sites-runtime/session-test.mjs'));
const env={VNE_SUPABASE_URL:AUTH_ORIGIN,VNE_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_test_fixture',VNE_PREVIEW_AUTH:'admin-test-only',DB:{forbidden:true}};
let calls=0,signins=0,verified=false,throwVerify=false,wrongId=false;
const csrf='a'.repeat(64),name='__Host-vne-preview-csrf';
const create=()=>({jar:new Map([[name,csrf]]),pending:new Map(),client:{auth:{getUser:async()=>{if(throwVerify)throw Error('network');return{data:{user:verified?{id:wrongId?'wrong':ADMIN_ID,is_anonymous:false}:null},error:null};},signInWithPassword:async()=>{signins++;return{error:null};},signOut:async()=>({error:null})}}});
const app=gate({fetch:async(req,e)=>{calls++;assert.deepEqual(Object.keys(e),['ASSETS']);assert.equal(req.headers.get('authorization'),null);assert.equal(req.headers.get('cookie'),null);return new Response('PUBLIC_UI');}},create);
const fetch=(p,options={})=>app.fetch(new Request(ORIGIN+p,options),env,{});
let r=await fetch('/');assert.equal(r.status,303);assert.equal(r.headers.get('location'),'/preview-login');assert.equal(calls,0);
r=await fetch('/preview-login');let html=await r.text();assert(html.includes('Вход ADMIN_TEST'));assert(!html.includes('PUBLIC_UI'));
const form={csrf,identifier:'ADMIN_TEST',password:'synthetic-password-not-real'};const post=(p,override={},origin=ORIGIN)=>fetch(p,{method:'POST',headers:{origin,'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({...form,...override})});
assert.equal((await post('/preview-login',{},'https://evil.test')).status,403);assert.equal(signins,0);
assert.equal((await post('/preview-login',{csrf:'wrong'})).status,403);assert.equal(signins,0);
assert.equal((await post('/preview-login',{identifier:'stranger@example.test'})).status,401);assert.equal(signins,0);
verified=true;r=await post('/preview-login');assert.equal(r.status,303);assert.equal(r.headers.get('location'),'/');assert.equal(signins,1);
r=await fetch('/',{headers:{authorization:'Bearer forged',cookie:'stolen=not-real','x-vne-site-admin-access':'yes'}});assert.equal(await r.text(),'PUBLIC_UI');assert.equal(r.headers.get('cache-control'),'private, no-store');assert.equal(r.headers.get('vary'),'Cookie');
wrongId=true;assert.equal((await fetch('/about')).status,303);wrongId=false;throwVerify=true;assert.equal((await fetch('/')).status,303);throwVerify=false;
assert.equal((await fetch('/preview-logout')).status,405);assert.equal((await post('/preview-logout')).status,303);
assert.equal((await fetch('/',{method:'POST'})).status,405);
assert.equal((await app.fetch(new Request('https://evil.test/'),env,{})).status,503);
assert.equal((await app.fetch(new Request(ORIGIN+'/'),{...env,VNE_SUPABASE_URL:'https://evil.test'},{})).status,503);
console.log('PASS session gate: anonymous, exact identity, CSRF, origin, failclosed, env/header stripping, logout, no-data mutation');
// Native HTML form POST needs a non-null same-origin Origin (Fetch standard).
verified=false;throwVerify=false;wrongId=false;
for(const method of ['GET','HEAD']){const page=await fetch('/preview-login',{method});assert.equal(page.status,200);assert.equal(page.headers.get('referrer-policy'),'same-origin');if(method==='HEAD')assert.equal(await page.text(),'');}
assert.equal((await fetch('/')).headers.get('referrer-policy'),'no-referrer');
for(const origin of ['null',undefined,'https://evil.test']){const before=signins;const headers={'content-type':'application/x-www-form-urlencoded'};if(origin!==undefined)headers.origin=origin;const denied=await fetch('/preview-login',{method:'POST',headers,body:new URLSearchParams(form)});assert.equal(denied.status,403);assert.equal(denied.headers.get('referrer-policy'),'no-referrer');assert.equal(signins,before);}
{const before=signins;const denied=await fetch('/preview-login',{method:'POST',headers:{origin:ORIGIN,'content-type':'application/x-www-form-urlencoded','sec-fetch-site':'cross-site'},body:new URLSearchParams(form)});assert.equal(denied.status,403);assert.equal(signins,before);}
{const before=signins;const denied=await post('/preview-login',{csrf:'wrong'});assert.equal(denied.status,403);assert.equal(signins,before);}
{const rejected=await post('/preview-login',{identifier:'wrong@example.test'});assert.equal(rejected.status,401);assert.equal(rejected.headers.get('referrer-policy'),'same-origin');assert((await rejected.text()).includes('action="/preview-login"'));}
verified=true;
for(const method of ['GET','HEAD']){const page=await fetch('/preview-login',{method});assert.equal(page.status,200);assert.equal(page.headers.get('referrer-policy'),'same-origin');if(method==='GET')assert((await page.text()).includes('action="/preview-logout"'));else assert.equal(await page.text(),'');}
{const before=signins;const accepted=await post('/preview-login');assert.equal(accepted.status,303);assert.equal(accepted.headers.get('location'),'/');assert.equal(signins,before+1);assert.equal(accepted.headers.get('referrer-policy'),'no-referrer');}
assert.equal((await post('/preview-logout')).headers.get('referrer-policy'),'no-referrer');
console.log('PASS native form policy: login GET/HEAD/rejected/connected same-origin; null/missing/foreign/cross-site/bad-CSRF denied before Auth; valid Origin accepted; other response policy unchanged');
