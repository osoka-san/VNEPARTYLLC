import {build} from 'esbuild';
import {cp,mkdir,readFile,writeFile,rm,readdir} from 'node:fs/promises';
const manifest=JSON.parse(await readFile('.openai/hosting.json','utf8'));
if(manifest.project_id!=='appgprj_6ac74b7bfbe88191a82f308a0955e849'||manifest.d1||manifest.r2)throw Error('Unexpected binding');
await rm('dist',{recursive:true,force:true});await mkdir('dist/server',{recursive:true});await cp('.output/server','dist/server',{recursive:true});await cp('.output/public','dist/client',{recursive:true});
const files=await readdir('dist/server');for(const f of files.filter(f=>f.includes('server-fn-resolver'))){const text=await readFile('dist/server/'+f,'utf8');if(text.includes('functionName:'))throw Error('Unexpected server functions');}
await build({entryPoints:['preview-v22/session-gate.mjs'],outfile:'dist/server/session-gate.mjs',bundle:true,format:'esm',platform:'neutral',mainFields:['module','main'],target:'es2022'});
// Inventory the exact emitted files. HTML, source maps and hosting metadata are never public bypasses.
async function walk(dir,prefix=''){let paths=[];for(const item of await readdir(dir,{withFileTypes:true})){const relative=prefix+'/'+item.name;if(item.name.startsWith('.')||item.name.startsWith('_'))continue;if(item.isDirectory())paths.push(...await walk(dir+'/'+item.name,relative));else if(item.isFile()&&!/\.(html?|map)$/i.test(item.name))paths.push(relative);}return paths;}
const assetPaths=(await walk('dist/client')).sort();if(assetPaths.length<10)throw Error('Missing static asset inventory');
await writeFile('dist/server/asset-paths.mjs','export const ASSET_PATHS = new Set('+JSON.stringify(assetPaths)+');\n');
await cp('preview-v22/status-fallback.mjs','dist/server/status-fallback.mjs');
await cp('preview-v22/guard.mjs','dist/server/preview-guard.mjs');await writeFile('dist/server/index.js',`import worker from './index.mjs';import guard from './preview-guard.mjs';import sessionGate from './session-gate.mjs';import {ASSET_PATHS} from './asset-paths.mjs';export default sessionGate(guard(worker,ASSET_PATHS));\n`);
await mkdir('dist/.openai',{recursive:true});await writeFile('dist/.openai/hosting.json',JSON.stringify(manifest));
await writeFile('dist/client/_headers','/*\n  X-Robots-Tag: noindex, nofollow\n  Cache-Control: private, no-store\n');
