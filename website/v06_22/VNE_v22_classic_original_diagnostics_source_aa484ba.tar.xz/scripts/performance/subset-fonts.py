#!/usr/bin/env python3
"""Reproducible OFL font derivatives; originals remain unchanged.
Run with Python + fontTools[woff] (this environment: /usr/bin/python3).
The core covers RU/EN, combining marks, punctuation, currency and digits.
All other original codepoints remain in the disjoint extended subset.
"""
from pathlib import Path
import hashlib
import json
from fontTools import subset
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[2]
FONTS = ROOT / 'public/fonts'
OUT = FONTS / 'subsets-v1'
RANGES = [(0x0000, 0x00FF), (0x0300, 0x036F), (0x0400, 0x052F),
          (0x1C80, 0x1C8F), (0x2000, 0x206F), (0x20A0, 0x20CF),
          (0x2100, 0x214F), (0x2190, 0x22FF), (0x25A0, 0x27FF), (0x2DE0, 0x2DFF),
          (0xA640, 0xA69F), (0xFE2E, 0xFE2F), (0xFEFF, 0xFEFF), (0xFFFD, 0xFFFD)]


def unicode_ranges(points):
    runs = []
    for point in sorted(points):
        if runs and point == runs[-1][1] + 1:
            runs[-1][1] = point
        else:
            runs.append([point, point])
    return ', '.join(f'U+{a:04X}' if a == b else f'U+{a:04X}-{b:04X}' for a, b in runs)


def main():
    OUT.mkdir(exist_ok=True)
    manifest = []
    faces = []
    for family, weights in [('Unbounded', '200 900'), ('Onest', '100 900')]:
        original = FONTS / f'{family}-Variable.woff2'
        font = TTFont(original, recalcTimestamp=False)
        cmap = font.getBestCmap()
        core = {cp for cp in cmap if any(lo <= cp <= hi for lo, hi in RANGES)}
        for label, codepoints in [('core', core), ('extended', set(cmap) - core)]:
            font = TTFont(original, recalcTimestamp=False)
            options = subset.Options()
            options.layout_features = ['*']
            options.name_IDs = ['*']
            options.name_legacy = True
            options.name_languages = ['*']
            options.notdef_outline = True
            options.recommended_glyphs = True
            options.recalc_timestamp = False
            subsetter = subset.Subsetter(options=options)
            subsetter.populate(unicodes=codepoints)
            subsetter.subset(font)
            target = OUT / f'{family}-Variable-{label}.woff2'
            font.save(target)
            ranges = unicode_ranges(codepoints)
            manifest.append({'source': original.name, 'sourceSha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                             'derivative': 'subsets-v1/' + target.name, 'bytes': target.stat().st_size,
                             'codepointCount': len(codepoints), 'unicodeRange': ranges,
                             'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
            faces.append(f'''@font-face {{
  font-family: "{family}";
  src: url("./subsets-v1/{target.name}") format("woff2");
  font-style: normal;
  font-weight: {weights};
  font-display: swap;
  unicode-range: {ranges};
}}''')
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    css = (FONTS / 'fonts.css').read_text()
    tail = css[css.index('@font-face {\n  font-family: "HealthGoth";'):]
    header = '''/*
 * VNE typography kit. OFL 1.1 licenses and original WOFF2 files are retained.
 * Unbounded/Onest derivatives are lossless Unicode subsets, not redesigned fonts.
 * Core: RU/EN, digits, combining marks, punctuation and currencies.
 * Extended: every remaining original character, loaded only when used.
 * Rebuild: scripts/performance/subset-fonts.py. HealthGoth is unmodified.
 */\n\n'''
    (FONTS / 'fonts.css').write_text(header + '\n\n'.join(faces) + '\n\n' + tail)
    print(json.dumps(manifest, indent=2))

if __name__ == '__main__':
    main()
